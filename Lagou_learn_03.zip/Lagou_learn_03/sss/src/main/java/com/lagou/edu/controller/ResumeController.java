package com.lagou.edu.controller;

import com.lagou.edu.dao.ResumeDao;
import com.lagou.edu.pojo.Resume;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;


@Controller
@ContextConfiguration(locations = {"classpath:applicationContext.xml"})
@RequestMapping("/admin/resume")
public class ResumeController<查询所有表内容> {

    /**
     * Spring容器和SpringMVC容器是有层次的（父子容器）
     * Spring容器：service对象+dao对象
     * SpringMVC容器：controller对象，，，，可以引用到Spring容器中的对象
     */




    @Autowired
    private ResumeDao resumeDao;
    @RequestMapping("/dataAll")
    public ModelAndView dataAll()throws Exception{
        //调用Service层进行数据查找
        List<Resume> dataLists = resumeDao.findAll();

        System.out.println(dataLists);
        ModelAndView modelAndView = new ModelAndView();

        //将数据放到request中
        modelAndView.addObject("dataLists", dataLists);

        //指定视图
        modelAndView.setViewName("/list");

        return modelAndView;
    }

    /**
     * 查询所有表内容
     */
    @RequestMapping("/queryAll")
    public void queryAll() throws Exception {
        List<Resume> list = resumeDao.findAll();
        for (int i = 0; i < list.size(); i++) {
            Resume resume =  list.get(i);
            System.out.println(resume);
        }
    }

   /* *
     * 增加数据
     */


    @RequestMapping(value = "/add")
    public ModelAndView addView() {
        return new ModelAndView("/add");
    }

    @RequestMapping(value = "/addUser",method = RequestMethod.POST)
    public String addSubmit(Resume resume) {
        resumeDao.save(resume);
        return "redirect:/list";
    }



   /* *
     * 编辑更新表数据
     */
    @RequestMapping("/update")
    public ModelAndView updateInfo(Long id,String name,String address,String phone) throws Exception {
        Resume resume = new Resume();
        resume.setId(id);
        resume.setName("name");
        resume.setAddress("address");
        resume.setPhone("phone");
        Resume save = resumeDao.save(resume);
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.addObject("save", save);

        //指定视图
        modelAndView.setViewName("/list");

        return modelAndView;




    }

    /**
     * 删除
     */
    @RequestMapping(value = "/delete/{id}", method = RequestMethod.DELETE)
    public ModelAndView delete(@PathVariable Long id) {
        ModelAndView modelAndView = new ModelAndView();
        try {
            resumeDao.deleteById(id);
            return modelAndView.addObject("delete","success");
        }catch (Exception e) {
            return modelAndView.addObject("delete","fail");
        }

    }

}
